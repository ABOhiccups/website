==================================================
Instructions
==================================================

Thank you for download AVGN VS Ganon.

To play this ROM Hack, You need the following itmes.

- The Legend of Zelda: A Link to the Past US ROM (without Header)
- Lunar IPS, Floating IPS, or any IPS Patcher Software

Just patch the ROM and you're all set!

==================================================
MSU1 Support
==================================================

This ROM Hack also supports MSU1.

Download MSU1 Pack.
https://drive.google.com/file/d/1KrhJV6bu31dsYyve1kZivF5m3AI28Yqe/view?usp=drive_link

Make sure you rename a Patched ROM File to "AVGN_VS_Ganon.sfc".

Place a Patched ROM File in the same directory as MSU1 Pack.

==================================================
How to play MSU1?
==================================================

To play MSU1 on Emulator. You need a Emulator that supports MSU1.

- bsnes
- higan
- Snes9x
- RetroArch with Snes9x Core

To play MSU1 on Official Super Nintendo Console or Super NT FPGA Clone Console.

You need a Flash Cartridge that supports MSU1.

- SD2SNES
- SD2SNES Pro / FXPAK Pro
