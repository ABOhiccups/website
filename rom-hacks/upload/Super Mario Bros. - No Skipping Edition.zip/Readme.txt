Thank you for downloading Super Mario Bros. - No Skipping Challenge.

To run this Hack. You need a ROM of Super Mario Bros. for NES to patch.

Here's a link to download Lunar IPS.
http://www.romhacking.net/utilities/240/