Thank you for downloading!

Original SD2SNES:
Place "menu.bin" to "X:/sd2snes/" on your SD Card and replace a file.

FXPAK Pro / SD2SNES Pro:
Place "m3nu.bin" to "X:/sd2snes/" on your SD Card and replace a file.

==================================================
NOTE:
==================================================

This Custom Menu supports Version 1.10.3.

If the newer Firmware Version is available.

Visit https://sd2snes.de/themes/ and follow instructions.